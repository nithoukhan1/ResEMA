# Detection Project — Chat 23 R9B R3 Native Worker Integration CANDIDATE

**Status: CPU integration candidate. No runnable GPU training command, no official-training authority. B-TEST is sealed.**

## Exact parent lineage
- Chat 23 R9B native boundary R2 ZIP: SHA256 `12aa1e806d430c62f52363957527c7468bab3500f09fd936d344bc8c434c431c` (physically included).
- R9B control-plane R1 ZIP: SHA256 `c354dd49ad76c9317ae7e6f39864a526a44648a53f92988485c98bb2caed7b81` (nested inside R2).
- R9A source/transport engineering R1 ZIP: SHA256 `c9aa976bff0710a2581b619008b7056ab398f498201cb857e86ed96e0e9ae734` (nested inside R1).
- R9 candidate AMP recipe SHA256 `dd0ef5903dc3229abfe0c5e9298d0c288e3c682d2d14a8314530caf4ad3ad074`.
- Historical Chat 23 R8 CUDA selected-best evaluation acceptance: both arms PASS, test-only, no optimizer steps; actual epoch100 not exercised.

## New work
1. `R9B_R3_NATIVE_WORKER_INTEGRATION.py`: explicit frozen two-arm settings, safe run-plan validation, full 336+7 source byte verification, actual native class composition (`R9BPostPublicationSessionStopMixin` + G4) and recovery-configuration method wiring. Runtime plan CLI is **CPU/plan-only**, no `trainer.train()` call.
2. Resume checks require the ORIGINAL off-session verified transport ZIP + sidecar + separate attestation + staged files; all original ZIP members are rechecked by the R9A exact transport verifier. Selected best must be copied before native restoration, and original authenticated capsule/receipt are copied into the NEW checkpoint_root. The staged off-session artifact stays unchanged.
3. `R9B_R3_PROVENANCE_ENVELOPE.py`: create an immutable, candidate-only proof envelope without rewriting historic G4 `official_training_authorized=false` records or pretending Kaggle export is durable. New official-release authorization remains a separate future control.
4. Tests: `TEST_R9B_R3_CPU.py` (positive/negative plan, class assembly, provenance, forbidden states) and `TEST_R9B_R3_SOURCE_STAGE_CPU.py` (actual nested R9A 336+7 bytes, corruption rejection, recovery).

## Verified / unverified boundaries
- All provided tests are CPU-only; 31 functional tests PASS and a separate authentic-source staging/tamper test PASS.
- The compiled Python files parse; no models loaded, no GPU used, no training executed, no B-TEST access.
- The `configure_authenticated_trainer` function is *not* yet GPU verified, and this archive deliberately has **no executable native training CLI**. It is not a production launcher.
- Real GPU fresh/resume, two-arm session boundary, offsite Windows verification and reimport, native epoch100 terminal handling, Kaggle quota/storage policy, and the official release authorization all remain pending.
- Do NOT turn on training by removing a `false` field; R9 recipe and historical G4 identities are governance evidence, not an on/off training permit.

## CPU verification (optional, no Kaggle needed)
```
python TEST_R9B_R3_CPU.py
python TEST_R9B_R3_SOURCE_STAGE_CPU.py
```

## Shortest remaining plan / Chat 24 migration
- Preserve this R3 archive as the final Chat 23 engineering checkpoint; migrate Chat 1–23 -> Chat 24 **now**, before official training.
- In Chat 24: finish a real bounded native acceptance worker with explicit non-official authorization, validate source/input paths on Kaggle, perform minimal fresh/resume GPU lifecycle acceptance and external transfer verification. Treat native epoch100 as unproven until actual terminal boundary evidence is obtained.
- Freeze the authentic 100-epoch launcher and external storage plan only after acceptance. Obtain explicit user authorization before initiating fresh official MV00/MV01 training. Never resume R7 rehearsal state as an official run.
