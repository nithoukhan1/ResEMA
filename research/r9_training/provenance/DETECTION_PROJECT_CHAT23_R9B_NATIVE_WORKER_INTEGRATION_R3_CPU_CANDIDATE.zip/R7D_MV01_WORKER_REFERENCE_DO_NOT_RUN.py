# Isolated one-visible-GPU worker, genuine epoch-2 resume.
import os, sys, json, hashlib, shutil, time, math
from pathlib import Path

def h(p):
    v=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):v.update(b)
    return v.hexdigest()

def need(v,label):
    if not v: raise RuntimeError('R7D_CHILD_FAIL_CLOSED_'+label)

arm, basedir, conf, outreport=sys.argv[1:]
need(arm in ('MV00','MV01'),'ARM')
expected_mask='0' if arm=='MV00' else '1'
assigned=os.environ.get('CUDA_VISIBLE_DEVICES')
need(assigned==expected_mask,'PARENT_PHYSICAL_GPU_ASSIGNMENT')
base=Path(basedir).resolve(strict=True)
root=base/arm
source=Path(os.environ['R7D_AUTHENTIC_SOURCE']).resolve(strict=True)
mods=Path(os.environ['R7D_AUTHENTIC_MODULES']).resolve(strict=True)
recipe=Path(os.environ['R7D_AUTHENTIC_RECIPE']).resolve(strict=True)
staged=Path(os.environ['R7D_AUTHENTIC_STAGED']).resolve(strict=True)
manifest=json.loads((base/'R7D_R6_SOURCE_REFERENCE.json').read_bytes())
need(h(source.parent/'R7C_SOURCE_MANIFEST.json')==manifest['manifest_sha256'],'SOURCE_MANIFEST_SHA')
need(h(recipe)==manifest['recipe_sha256'],'RECIPE_PIN')
need(h(conf)==manifest['rebased_config_sha256'],'CONFIG_PIN')
need(h(staged/'RUNTIME_YAML.yaml')==manifest['data_yaml_sha256'],'YAML_PIN')
import torch
need(torch.cuda.is_available() and torch.cuda.device_count()==1,'GPU_COUNT')
need('T4' in torch.cuda.get_device_name(0).upper(),'NOT_T4')
need('ultralytics' not in sys.modules,'EARLY_ULTRALYTICS_IMPORT')
sys.path.insert(0,str(mods));sys.path.insert(0,str(source));os.chdir(source)
import ultralytics
need(Path(ultralytics.__file__).resolve().is_relative_to(source),'NONPINNED_ULTRALYTICS')
from ultralytics.models.yolo.detect.early_paired_trainer import EarlyPairedTrainer
from ultralytics.models.yolo.detect.vgra_trainer import VGRADetectionTrainer
from g4c_guarded_trainer_class_binding_candidate_R4 import bind_candidate_class
from g4_epoch_stream_publisher_candidate_R3 import verify_epoch
class R7DStopAfterResumedEpoch(Exception):pass
class R7DStopMixin:
    def d4e_recovery_epoch_end(self,epoch,nb,last_opt_step):
        super().d4e_recovery_epoch_end(epoch,nb,last_opt_step)
        if epoch == 1:
            need(self._d4e_recovery_restored,'RECOVERY_NOT_EXECUTED')
            need(self.start_epoch==1,'WRONG_RESUME_EPOCH')
            need(len(self._g4_completed)==1,'ONE_NEW_PUBLISHED_BUNDLE')
            need(len(self._d4e_epoch_receipts)==1,'ONE_NEW_CAPSULE')
            need(self._d4e_optimizer_updates>self._r7d_baseline_updates,'NO_NEW_OPTIMIZER_STEPS')
            need(self.ema.updates==self._d4e_optimizer_updates,'EMA_COUNTER')
            need(self._d4_optimizer_steps_observed==self._d4e_optimizer_updates,'POST_HOOK_COUNTER')
            need(self.scaler.is_enabled() and float(self.scaler.get_scale())>=1,'SCALER_STATE')
            raise R7DStopAfterResumedEpoch('BOUNDARY_TEST_ONLY')
class R7DAMPLaunchMixin:
    def __init__(self,*args,**kwargs):
        self._r7c_amp_gate_ready=True
        super().__init__(*args,**kwargs)
Native={'MV00':EarlyPairedTrainer,'MV01':VGRADetectionTrainer}[arm]
Base=bind_candidate_class(Native)
Trainer=type(Native.__name__,(R7DStopMixin,R7DAMPLaunchMixin,Base),{'__module__':__name__})
evidence=json.loads((root/'R7D_R6_STAGE.json').read_bytes())
need(evidence['arm']==arm and evidence['official_training_authorized'] is False,'STAGED_GOVERNANCE')
need(evidence['recipe_sha256']==h(recipe),'STAGED_RECIPE')
rootcaps=root/'capsules'
receipt_pin=evidence['external_receipt_sha256']
checkpoint=rootcaps/evidence['capsule_filename']
need(h(checkpoint)==evidence['capsule_sha256'],'STAGED_CHECKPOINT_SHA')
need(h(checkpoint.with_suffix('.receipt.json'))==receipt_pin,'STAGED_RECEIPT_SHA')
settings={
 'data':str(staged/'RUNTIME_YAML.yaml'),'task':'detect','imgsz':1024,'batch':8,
 'device':'0','seed':42,'deterministic':True,'epochs':100,'patience':100,
 'optimizer':'SGD','lr0':0.01,'lrf':0.01,'momentum':0.937,
 'weight_decay':0.0005,'nbs':64,'cos_lr':True,'amp':True,
 'workers':0,'cache':False,'compile':False,'rect':False,
 'multi_scale':0.0,'fraction':1.0,'single_cls':False,'mosaic':0.0,
 'mixup':0.0,'cutmix':0.0,'copy_paste':0.0,'plots':False,
 'save':True,'val':True,'resume':False,'exist_ok':False,
 'project':str(root/'native_training_runs'),
 'name':arm+'_R7D_RESUMED_EPOCH_TWO_TEST_ONLY'
}
trainer=Trainer(train_assignment_manifest=str(staged/'TRAIN_ASSIGNMENT.csv'),
    val_assignment_manifest=str(staged/'TRAIN_ASSIGNMENT.csv'),
    train_visibility_evidence=str(staged/'TRAIN_VISIBILITY.json'),
    pretrained_archive=str(staged/'PRETRAINED_ARCHIVE.zip'),
    pretrained_best=str(staged/'PRETRAINED_BEST.pt'),overrides=settings)
# The native weights directory exists immediately after __init__; restore selected
# best independently before d4e_recovery_start() checks its authenticated digest.
need(not trainer.best.exists(),'OUTPUT_BEST_ALREADY_EXISTS')
with Path(evidence['copy_selected_best']).open('rb') as src,trainer.best.open('xb') as dst:
    shutil.copyfileobj(src,dst)
need(h(trainer.best)==evidence['selected_best_sha256'],'PRELOADED_BEST_SHA')
trainer.d4e_configure_recovery(mode='RESUME_FROM_OUR_OWN_RUN',
    config_path=conf,recipe_path=str(recipe),
    approved_runtime_yaml_sha256=manifest['data_yaml_sha256'],
    arm=arm,run_id=evidence['run_id'],checkpoint_root=rootcaps,
    checkpoint_path=checkpoint,trusted_receipt_sha256=receipt_pin)
need(trainer._d4e_verified_identity==evidence['identity'],'R5_IDENTITY_NOT_REPRODUCED')
need(trainer._d4e_verified_identity['recipe_sha256']==h(recipe),'RECIPE_BINDING')
trainer.d4e_g3b5_bind_guard(arm=arm,failure_root=root/'private_guard_failure')
trainer.g4_bind_epoch_publication(output_root=root/'publication')
trainer._r7d_baseline_updates=int(evidence['checkpoint_cursor']['optimizer_updates'])
need(trainer._r7d_baseline_updates==974,'BASELINE_UPDATE_DRIFT')
t0=time.monotonic()
try:
    trainer.train()
except R7DStopAfterResumedEpoch:
    pass
else:
    raise RuntimeError('R7D_NATIVE_EPOCH_TWO_BOUNDARY_STOP_NOT_OBSERVED')
need(trainer._d4e_recovery_restored,'NO_REAL_RESTORE')
need(trainer.start_epoch==1 and trainer.epoch==1,'WRONG_EPOCH_CURSOR')
need(trainer._d4e_optimizer_updates>974,'OPTIMIZER_UPDATES_DID_NOT_ADVANCE')
need(trainer.ema.updates==trainer._d4e_optimizer_updates,'EMA_AFTER_RESUME')
need(trainer._d4_optimizer_steps_observed==trainer._d4e_optimizer_updates,'POST_HOOK_AFTER_RESUME')
need(trainer.scaler.is_enabled(),'SCALER_DISABLED_AFTER_RESUME')
need(trainer._g4_guard_records[1]['validator_pass'] is True,'BVAL_NOT_COMPLETED')
new_manifest=trainer._g4_completed[0]
need(new_manifest['completed_epoch']==1 and new_manifest['terminal'] is False,'RESUMED_BUNDLE_CURSOR')
proof=verify_epoch(root=root/'publication',arm=arm,epoch=1,
    external_manifest_sha256=new_manifest['manifest_sha256'])
need(proof['status']=='G4C_LOCAL_VERIFICATION_PASS_ONLY','NEW_BUNDLE_INVALID')
# Test the actual G4 final_eval() implementation (B-VAL), not a synthetic
# test-time inference shortcut. This is a bounded method test, NOT a terminal
# epoch-100 branch or terminal publication.
before_best=h(trainer.best);before_last=h(trainer.last)

import ultralytics.nn.tasks as _r7_tasks
from ultralytics.models.yolo.detect import early_paired_trainer as _r7_early
_R7_ORIGINAL_LOAD = _r7_tasks.load_checkpoint
_R7_REBUILDS=[]
def _r7_criterion_device_rebind(*args,**kwargs):
    model,ckpt=_R7_ORIGINAL_LOAD(*args,**kwargs)
    crit=getattr(model,'criterion',None)
    if crit is not None:
        cdevice=getattr(crit,'device',None)
        proj=getattr(crit,'proj',None)
        pdevice=getattr(proj,'device',None)
        mdevice=next(model.parameters()).device
        # The saved loss object may claim CUDA as `device` yet retain its
        # *non-buffer* distribution projection vector on CPU after loading.
        stale=(cdevice is not None and cdevice!=mdevice) or (pdevice is not None and pdevice!=mdevice)
        if stale:
            need(mdevice.type=='cuda' and pdevice is not None and pdevice.type=='cpu','UNEXPECTED_CRITERION_PROJECTION_DRIFT')
            # Nonregistered temporary criterion, not model parameters/buffers.
            model.criterion=None
            _R7_REBUILDS.append({'criterion_device':str(cdevice),'projection_device':str(pdevice),'new_model_device':str(mdevice)})
    return model,ckpt
_r7_tasks.load_checkpoint=_r7_criterion_device_rebind
_r7_early.load_checkpoint=_r7_criterion_device_rebind

trainer.final_eval()
need(_R7_REBUILDS,'EXPECTED_CPU_CRITERION_REBUILD_NOT_OBSERVED')

need(trainer._g4_eval_completed is True,'FINAL_EVAL_METHOD_NOT_COMPLETED')
a=trainer._g4_eval_attestation
need(a['evaluation_operated_on_disposable_copies'] is True,'DISPOSABLE_COPY_EVAL')
need(a['original_checkpoint_bytes_preserved'] is True,'CKPT_PRESERVATION')
need(a['selected_best_sha256']==before_best and a['last_sha256']==before_last,'EVAL_ATTESTATION')
need(h(trainer.best)==before_best and h(trainer.last)==before_last,'POST_EVAL_BYTES_DRIFT')
need(isinstance(trainer.metrics,dict) and bool(trainer.metrics),'FINAL_EVAL_METRICS_EMPTY')
def finite(obj):
    if isinstance(obj,dict):
        return all(finite(x) for x in obj.values())
    if isinstance(obj,(tuple,list)):
        return all(finite(x) for x in obj)
    if isinstance(obj,(int,float)):
        return math.isfinite(float(obj))
    if isinstance(obj,torch.Tensor):
        return bool(torch.isfinite(obj).all().item())
    return True
need(finite(trainer.metrics),'FINAL_EVAL_METRICS_NONFINITE')
new_receipt=trainer._d4e_epoch_receipts[-1]
new_cap=Path(new_receipt['checkpoint'])
need(h(new_cap)==new_receipt['checkpoint_sha256'],'RESUMED_CAPSULE_DRIFT')
need(h(new_cap.with_suffix('.receipt.json'))==new_receipt['trusted_receipt_sha256'],'RESUMED_RECEIPT_DRIFT')
report={
 'schema':'D4F_R7D_R6_OFFSESSION_RESUME_EVAL_TEST_ONLY',
 'status':'PASS_NATIVE_EPOCH2_AMP_RESTORE_AND_BOUNDED_FINAL_EVAL',
 'arm':arm,'parent_assigned_physical_gpu_ordinal':assigned,
 'gpu_visible_name':torch.cuda.get_device_name(0),
 'loaded_original_R7C_completed_epoch':0,'new_completed_epoch':1,
 'previous_optimizer_updates':974,
 'restored_and_advanced_optimizer_updates':trainer._d4e_optimizer_updates,
 'optimizer_post_hook_updates':trainer._d4_optimizer_steps_observed,
 'ema_updates':trainer.ema.updates,
 'grad_scaler_enabled':bool(trainer.scaler.is_enabled()),
 'grad_scaler_current_scale':float(trainer.scaler.get_scale()),
 'resumed_native_epoch_seconds_including_validation':round(time.monotonic()-t0,3),
 'r7c_source_manifest_sha256':manifest['manifest_sha256'],
 'recipe_sha256':manifest['recipe_sha256'],
 'rebased_config_sha256':manifest['rebased_config_sha256'],
 'source_weights_best_sha256':before_best,'source_weights_last_sha256':before_last,
 'new_epoch_bundle_manifest_sha256':new_manifest['manifest_sha256'],
 'new_recovery_capsule_sha256':new_receipt['checkpoint_sha256'],
 'new_external_recovery_receipt_sha256':new_receipt['trusted_receipt_sha256'],
 'guarded_final_eval_attestation':a,
 'selected_best_bval_metrics':{str(k):float(v) if isinstance(v,(int,float)) else str(v)
                               for k,v in trainer.metrics.items()},
 'new_checkpoint_terminal':False,
 'full_100_epoch_terminal_branch_tested':False,
 'official_training_authorized':False,'b_test_access':'NONE',
 'limitations':['Two completed epochs in test-only run, not official training',
                'Guarded selected-best final_eval method invoked after bounded stop',
                'Actual epoch-100 terminal branch not exercised',
                'A successful method test does not guarantee Kaggle long-run session reliability']
}
with Path(outreport).open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print('R7D_R6_ARM_PASS=',arm,'RESTORED_EPOCH=1','OPTIMIZER_STEPS=',report['restored_and_advanced_optimizer_updates'],
      'BVAL_SELECTED_BEST_EVAL=PASS','NEW_REPORT_SHA256=',h(outreport),flush=True)
