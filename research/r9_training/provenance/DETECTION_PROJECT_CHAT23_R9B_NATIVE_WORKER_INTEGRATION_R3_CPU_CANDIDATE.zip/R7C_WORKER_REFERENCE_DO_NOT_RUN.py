# R7-C CHILD: authentic native epoch, bounded stop after first local publication.
import os,sys,json,hashlib,time
from pathlib import Path

def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def require(ok,msg):
    if not ok: raise RuntimeError('R7C_CHILD_FAIL_CLOSED_'+msg)

arm, planpath, basedir, reportfile = sys.argv[1:]
require(arm in ('MV00','MV01'),'ARM')
# Capture original physical assignment BEFORE Ultralytics rewrites this variable.
assigned_device=os.environ.get('CUDA_VISIBLE_DEVICES')
require(assigned_device == ('0' if arm=='MV00' else '1'),'PARENT_GPU_ASSIGNMENT')
base=Path(basedir).resolve(strict=True)
source=(base/'isolated_source').resolve(strict=True)
mods=(base/'integration_modules').resolve(strict=True)
meta=json.loads((base/'R7C_SOURCE_MANIFEST.json').read_bytes())
def all_source_files(root):
    return {p.relative_to(root).as_posix() for p in root.rglob('*')
            if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
require(all_source_files(source)==set(meta['source_sha256']),'SOURCE_FILE_INVENTORY_DRIFT')
require(all_source_files(mods)==set(meta['modules_sha256']),'MODULE_FILE_INVENTORY_DRIFT')
for relative,pin in meta['source_sha256'].items():
    require(digest(source/relative)==pin,'SOURCE_MANIFEST_'+relative.replace('/','_'))
for relative,pin in meta['modules_sha256'].items():
    require(digest(mods/relative)==pin,'MODULE_MANIFEST_'+relative)
require(digest(base/'R7C_AMP_RECIPE.json')==meta['recipe_sha256'],'RECIPE_SHA')
require(meta['official_training_authorized'] is False,'AUTHORIZATION')
import torch
require(torch.cuda.is_available() and torch.cuda.device_count()==1,'ONE_VISIBLE_GPU')
require('T4' in torch.cuda.get_device_name(0).upper(),'T4_REQUIRED')
sys.path.insert(0,str(mods));sys.path.insert(0,str(source));os.chdir(source)
import ultralytics
require(Path(ultralytics.__file__).resolve().is_relative_to(source),'UNTRUSTED_LIBRARY')
from ultralytics.models.yolo.detect.early_paired_trainer import EarlyPairedTrainer
from ultralytics.models.yolo.detect.vgra_trainer import VGRADetectionTrainer
from g4c_guarded_trainer_class_binding_candidate_R4 import bind_candidate_class
from g4_epoch_stream_publisher_candidate_R3 import verify_epoch
plan=json.loads(Path(planpath).read_bytes())
require(plan['status']=='AUTHENTICATED_SOURCE_READY_TEST_ONLY','PLAN_STATUS')
Native={'MV00':EarlyPairedTrainer,'MV01':VGRADetectionTrainer}[arm]
Base=bind_candidate_class(Native)
class R7CNativeAMPLaunchMixin:
    def __init__(self, *args, **kwargs):
        self._r7c_amp_gate_ready=True
        super().__init__(*args, **kwargs)
class R7COneEpochStop(Exception):pass
class R7COneEpochStopMixin:
    def d4e_recovery_epoch_end(self, epoch, nb, last_opt_step):
        super().d4e_recovery_epoch_end(epoch,nb,last_opt_step)
        if epoch==0:
            require(len(self._g4_completed)==1,'ONE_EPOCH_PUBLISHED')
            require(len(self._d4e_epoch_receipts)==1,'ONE_RESUMABLE_CAPSULE')
            require(self._d4e_optimizer_updates>0,'NO_OPTIMIZER_UPDATES')
            require(self.ema.updates==self._d4e_optimizer_updates,'EMA_COUNTER_MISMATCH')
            require(self._d4_optimizer_steps_observed==self._d4e_optimizer_updates,'POST_HOOK_COUNTER_MISMATCH')
            require(self.scaler.is_enabled() and float(self.scaler.get_scale())>0,'SCALER_DRIFT')
            raise R7COneEpochStop('BOUNDED_TEST_ONLY_AFTER_VERIFIED_AMP_EPOCH')
Trainer=type(Native.__name__,(R7COneEpochStopMixin,R7CNativeAMPLaunchMixin,Base),{'__module__':__name__})
work=base/(arm+'_native_epoch')
work.mkdir(mode=0o700,exist_ok=False)
fail=work/'private_guard_failure';fail.mkdir(mode=0o700)
publication=work/'local_immutable_bundles';publication.mkdir(mode=0o700)
caps=work/'authentic_recovery_capsules';caps.mkdir(mode=0o700)
settings={
 'data':plan['runtime_yaml'],'task':'detect','imgsz':1024,'batch':8,'device':'0','seed':42,
 'deterministic':True,'epochs':100,'patience':100,'optimizer':'SGD','lr0':0.01,
 'lrf':0.01,'momentum':0.937,'weight_decay':0.0005,'nbs':64,'cos_lr':True,
 'amp':True,'workers':0,'cache':False,'compile':False,'rect':False,
 'multi_scale':0.0,'fraction':1.0,'single_cls':False,'mosaic':0.0,
 'mixup':0.0,'cutmix':0.0,'copy_paste':0.0,'plots':False,'save':True,
 'val':True,'resume':False,'exist_ok':False,'project':str(work/'training_runs'),
 'name':arm+'_R7C_NATIVE_AMP_ONE_EPOCH_TEST_ONLY'
}
trainer=Trainer(train_assignment_manifest=plan['assignment'],val_assignment_manifest=plan['assignment'],
    train_visibility_evidence=plan['visibility'],pretrained_archive=plan['pretrained_archive'],
    pretrained_best=plan['pretrained_best'],overrides=settings)
trainer.d4e_configure_recovery(mode='FRESH_FROM_EARLY',
    config_path=plan['config_path'],recipe_path=str(base/'R7C_AMP_RECIPE.json'),
    approved_runtime_yaml_sha256='f2cc6e31f5f1be152f4dd7603a397e142963923f1d35de613eb7c61b168bf0c0',
    arm=arm,run_id='D4F_R7C_TESTONLY_'+arm,
    checkpoint_root=caps)
require(trainer._d4e_verified_identity['recipe_sha256']==meta['recipe_sha256']
    if 'recipe_sha256' in trainer._d4e_verified_identity else
    trainer._d4e_verified_identity==trainer._d4e_recovery_identity,
    'RECOVERY_IDENTITY')
trainer.d4e_g3b5_bind_guard(arm=arm,failure_root=fail)
trainer.g4_bind_epoch_publication(output_root=publication)
started=time.monotonic()
try:
    trainer.train()
except R7COneEpochStop:
    pass
else:
    raise RuntimeError('R7C_NATIVE_BOUNDED_STOP_NOT_OBSERVED')
seconds=time.monotonic()-started
require(trainer._d4e_optimizer_updates>0,'NO_NATIVE_OPTIMIZER_UPDATES')
require(trainer._d4_optimizer_steps_observed==trainer._d4e_optimizer_updates,'HOOK_COUNTER_DRIFT')
require(trainer.ema.updates==trainer._d4e_optimizer_updates,'EMA_COUNTER_DRIFT')
require(trainer.scaler.is_enabled() and float(trainer.scaler.get_scale())>=1,'SCALER_NOT_ACTIVE')
entry=trainer._g4_completed[0]
require(entry['completed_epoch']==0 and entry['terminal'] is False,'EPOCH_BUNDLE_INVALID')
verified=verify_epoch(root=publication,arm=arm,epoch=0,external_manifest_sha256=entry['manifest_sha256'])
require(verified.get('status')=='G4C_LOCAL_VERIFICATION_PASS_ONLY','BUNDLE_VERIFICATION')
receipt=trainer._d4e_epoch_receipts[-1]
checkpoint=Path(receipt['checkpoint'])
require(checkpoint.is_file() and digest(checkpoint)==receipt['checkpoint_sha256'],'CAPSULE_BYTES_DRIFT')
assert len(trainer.train_loader.dataset.im_files)==14227
report={
 'schema':'D4F_R7C_NATIVE_AMP_TEST_ONLY_R1',
 'status':'PASS_ONE_NATIVE_AMP_EPOCH_PAIR_VALIDATION_CAPSULE_LOCAL_ONLY',
 'arm':arm,'assigned_physical_cuda_ordinal_before_import':assigned_device,
 'visible_gpu_type':torch.cuda.get_device_name(0),'native_epoch_completed':1,
 'epoch_total_seconds_including_validation_and_save':round(seconds,3),
 'optimizer_updates':trainer._d4e_optimizer_updates,
 'optimizer_step_post_hook_updates':trainer._d4_optimizer_steps_observed,
 'ema_updates':trainer.ema.updates,'grad_scaler_scale':float(trainer.scaler.get_scale()),
 'new_recipe_sha256':meta['recipe_sha256'],
 'native_best_sha256':digest(trainer.best),'native_last_sha256':digest(trainer.last),
 'recovery_capsule_sha256':receipt['checkpoint_sha256'],
 'recovery_receipt_sha256':receipt['trusted_receipt_sha256'],
 'local_published_bundle_sha256':entry['manifest_sha256'],
 'source_manifest_sha256':digest(base/'R7C_SOURCE_MANIFEST.json'),
 'test_only':True,'official_training_authorized':False,
 'b_test_access':'NONE','offsession_restore_verified':False,
 'terminal_selected_best_eval_verified':False,
 'limitations':['one native epoch only','no authentic AMP restore after process restart',
   'no off-session transfer','no selected-best terminal-evaluation acceptance',
   'dynamic scaler overflow must abort; overflow resume needs separate review']
}
with Path(reportfile).open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print('R7C_ARM_NATIVE_AMP_LOCAL_PASS=',arm,'EPOCH_SECONDS=',report['epoch_total_seconds_including_validation_and_save'],
      'OPTIMIZER_UPDATES=',report['optimizer_updates'],flush=True)
