#!/usr/bin/env python3
"""Immutable separation of historical G4 byte evidence from future release authority.

Creates a SHA-256-pinned *candidate/non-authoritative* envelope for a locally
verified G4 manifest and externally reviewed capsule transport. Does not
retroactively alter G4, assert that offsite storage is durable, or authorize
training. Official receipts belong to a future release scope after user approval.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re
from pathlib import Path

ARMS=('MV00','MV01')

def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for c in iter(lambda:f.read(1<<20),b''):h.update(c)
    return h.hexdigest()

def envelope(*, manifest_path, arm, epoch, pin, recipe_sha256,
             source_archive_sha256, run_id, transport_attestation=None):
    p=Path(manifest_path)
    if not p.is_file() or p.is_symlink() or digest(p)!=pin:
        raise RuntimeError('R3_PROVENANCE_G4_MANIFEST_PIN_MISMATCH')
    obj=json.loads(p.read_bytes())
    if not (arm in ARMS and obj.get('arm')==arm and type(epoch) is int and
            obj.get('completed_epoch')==epoch and obj.get('b_test_access')=='NONE' and
            obj.get('schema')=='CHAT21_G4C_EPOCH_BUNDLE_CANDIDATE_R2_WITH_AUTHENTIC_RECEIPT' and
            obj.get('exported_off_session') is False and
            obj.get('official_training_authorized') is False):
        raise RuntimeError('R3_PROVENANCE_HISTORICAL_G4_IDENTITY')
    if not (isinstance(run_id,str) and re.fullmatch('[A-Za-z0-9_-]{1,128}',run_id)):
        raise RuntimeError('R3_PROVENANCE_RUN_ID')
    if recipe_sha256 != 'dd0ef5903dc3229abfe0c5e9298d0c288e3c682d2d14a8314530caf4ad3ad074':
        raise RuntimeError('R3_PROVENANCE_RECIPE')
    if source_archive_sha256 != 'c9aa976bff0710a2581b619008b7056ab398f498201cb857e86ed96e0e9ae734':
        raise RuntimeError('R3_PROVENANCE_SOURCE')
    transport=None
    if transport_attestation is not None:
        at=Path(transport_attestation)
        if not at.is_file() or at.is_symlink():raise RuntimeError('R3_PROVENANCE_EXTERNAL_ATTESTATION_FILE')
        a=json.loads(at.read_bytes())
        if a.get('schema')!='R9_OFFSITE_CHECK_NOT_NATIVE_RESUME_ACCEPTANCE' or a.get('arm')!=arm or a.get('completed_epoch')!=epoch or a.get('g4_manifest_sha256')!=pin:
            raise RuntimeError('R3_PROVENANCE_TRANSPORT_CONTEXT')
        transport={'external_attestation_sha256':digest(at),'transport_zip_sha256':a.get('zip_sha256'),
                   'bytes_independently_verified':True,'external_durability_established':False}
    return {'schema':'CHAT23_R9B_R3_G4_SEPARATE_PROVENANCE_CANDIDATE',
            'authority':'ENGINEERING_ONLY_NOT_USER_AUTHORIZATION','arm':arm,'run_id':run_id,
            'completed_epoch':epoch,'terminal':obj.get('terminal'),
            'g4_manifest_sha256':pin,'source_archive_sha256':source_archive_sha256,
            'recipe_sha256':recipe_sha256,'transport':transport,
            'historical_g4_authorization_field_unchanged':True,
            'official_training_authorized':False,'gpu_execution_performed':False,
            'native_resume_accepted':False,'b_test_access':'NONE'}

def main():
    pa=argparse.ArgumentParser(description=__doc__)
    pa.add_argument('--manifest',required=True);pa.add_argument('--arm',choices=ARMS,required=True)
    pa.add_argument('--completed-epoch',type=int,required=True);pa.add_argument('--manifest-sha256',required=True)
    pa.add_argument('--source-archive-sha256',required=True);pa.add_argument('--recipe-sha256',required=True)
    pa.add_argument('--run-id',required=True);pa.add_argument('--external-attestation')
    pa.add_argument('--out',required=True)
    a=pa.parse_args()
    rec=envelope(manifest_path=a.manifest,arm=a.arm,epoch=a.completed_epoch,
        pin=a.manifest_sha256,recipe_sha256=a.recipe_sha256,
        source_archive_sha256=a.source_archive_sha256,run_id=a.run_id,
        transport_attestation=a.external_attestation)
    out=Path(a.out)
    if out.exists() or out.is_symlink() or not out.parent.is_dir():raise FileExistsError('R3_PROVENANCE_NO_OVERWRITE')
    with out.open('x',encoding='utf8') as f:
        json.dump(rec,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
    print(json.dumps(rec,indent=2))
if __name__=='__main__':main()
